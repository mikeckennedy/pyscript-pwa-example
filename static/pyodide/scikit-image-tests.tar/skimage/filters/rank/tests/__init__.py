from ...._shared.testing import setup_test, teardown_test


def setup():
    setup_test()


def teardown():
    teardown_test()
